
import { useState, useEffect } from "react";
import "./App.css";

const partiturasMock = [
  { id: 1, titulo: "Ave Maria", arquivo: "/pdfs/ave-maria.pdf" },
  { id: 2, titulo: "Glória a Deus", arquivo: "/pdfs/gloria.pdf" },
  { id: 3, titulo: "Hosana nas Alturas", arquivo: "/pdfs/hosana.pdf" },
  { id: 4, titulo: "Pai Nosso", arquivo: "/pdfs/pai-nosso.pdf" },
  { id: 5, titulo: "Aleluia", arquivo: "/pdfs/aleluia.pdf" },
];

function App() {
  const [usuario, setUsuario] = useState({ nome: "Usuário Teste" });
  const [acessos, setAcessos] = useState(0);

  useEffect(() => {
    const acessosMes = parseInt(localStorage.getItem("kaind_acessos") || "0");
    setAcessos(acessosMes);
  }, []);

  const acessarPartitura = (p) => {
    if (acessos >= 4) {
      alert("Você atingiu o limite de 4 partituras este mês.");
      return;
    }
    window.open(p.arquivo, "_blank");
    const novoAcesso = acessos + 1;
    setAcessos(novoAcesso);
    localStorage.setItem("kaind_acessos", novoAcesso.toString());
  };

  if (!usuario) return <div className="App">Faça login para acessar o site.</div>;

  return (
    <div className="App">
      <h1>Kaindpartituras</h1>
      <p>Olá, {usuario.nome}! Você acessou {acessos}/4 partituras este mês.</p>
      <div className="grid">
        {partiturasMock.map((p) => (
          <div key={p.id} className="card">
            <h3>{p.titulo}</h3>
            <button onClick={() => acessarPartitura(p)}>Acessar PDF</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
